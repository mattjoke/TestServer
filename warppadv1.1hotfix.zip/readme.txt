Hello! 

Thank you for downloading Warp Pads v1.1 (Creation Fix)! I've poured my heart and soul into this, so I hope you like it!

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

This version of the data pack contains a small fix that was requested which will make it possible to create warp pads on a 1.14.4+ Spigot server.
To create the warp pads in this version, use the same recipes as the default version, but put all of the items on top of the gold, emerald or diamond block.

-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

If you like what I work on, subscribe to my YouTube channel! https://bit.ly/2PNWSJp
If you want to keep up to date with my projects and interact with me, follow me on twitter! https://twitter.com/SmoochyPit

If you decide to use any of my code, please credit me properly. Thank you!

-SmoochyPit

Credits: I used TheDestruc7ion's advancements generator (https://advancements.thedestruc7i0n.ca/) for creating the advancements